package com.test.toy.user.model;

public class UserDTO {

}
