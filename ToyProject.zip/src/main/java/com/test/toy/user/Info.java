package com.test.toy.user;

public class Info {

}
