package com.test.toy;

public class Template {

}
